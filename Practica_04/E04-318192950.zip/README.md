# Práctica 4 - Modelado Jerárquico

![Video](./Practica-04_Video.mp4)